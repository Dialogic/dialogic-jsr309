/*
 * DIALOGIC CONFIDENTIAL
 *
 * Copyright 2010 Dialogic Corporation. All Rights Reserved.
 * The source code contained or described herein and all documents related to
 * the source code (collectively "Material") are owned by Dialogic Corporation 
 * or its suppliers or licensors ("Dialogic"). 
 *
 * BY DOWNLOADING, ACCESSING, INSTALLING, OR USING THE MATERIAL YOU AGREE TO BE
 * BOUND BY THE TERMS AND CONDITIONS DENOTED HERE AND ANY ADDITIONAL TERMS AND
 * CONDITIONS SET FORTH IN THE MATERIAL. Title to the Material remains with 
 * Dialogic. The Material contains trade secrets and proprietary and 
 * confidential information of Dialogic. The Material is protected by worldwide
 * Dialogic copyright(s) and applicable trade secret laws and treaty provisions.
 * No part of the Material may be used, copied, reproduced, modified, published, 
 * uploaded, posted, transmitted, distributed, or disclosed in any way without
 * prior express written permission from Dialogic Corporation.
 *
 * No license under any applicable patent, copyright, trade secret or other 
 *intellectual property right is granted to or conferred upon you by disclosure
 * or delivery of the Material, either expressly, by implication, inducement, 
 * estoppel or otherwise. Any license under any such applicable patent, 
 * copyright, trade secret or other intellectual property rights must be express
 * and approved by Dialogic Corporation in writing.
 *
 * You understand and acknowledge that the Material is provided on an 
 * AS-IS basis, without warranty of any kind.  DIALOGIC DOES NOT WARRANT THAT 
 * THE MATERIAL WILL MEET YOUR REQUIREMENTS OR THAT THE SOURCE CODE WILL RUN 
 * ERROR-FREE OR UNINTERRUPTED.  DIALOGIC MAKES NO WARRANTIES, EXPRESS OR 
 * IMPLIED, INCLUDING, WITHOUT LIMITATION, ANY WARRANTY OF NON-INFRINGEMENT, 
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  DIALOGIC ASSUMES NO 
 * RISK OF ANY AND ALL DAMAGE OR LOSS FROM USE OR INABILITY TO USE THE MATERIAL. 
 * THE ENTIRE RISK OF THE QUALITY AND PERFORMANCE OF THE MATERIAL IS WITH YOU.  
 * IF YOU RECEIVE ANY WARRANTIES REGARDING THE MATERIAL, THOSE WARRANTIES DO NOT 
 * ORIGINATE FROM, AND ARE NOT BINDING ON DIALOGIC.
 *
 * IN NO EVENT SHALL DIALOGIC OR ITS OFFICERS, EMPLOYEES, DIRECTORS, 
 * SUBSIDIARIES, REPRESENTATIVES, AFFILIATES AND AGENTS HAVE ANY LIABILITY TO YOU 
 * OR ANY OTHER THIRD PARTY, FOR ANY LOST PROFITS, LOST DATA, LOSS OF USE OR 
 * COSTS OF PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES, OR FOR ANY INDIRECT, 
 * SPECIAL OR CONSEQUENTIAL DAMAGES RELATING TO THE MATERIAL, UNDER ANY CAUSE OF
 * ACTION OR THEORY OF LIABILITY, AND IRRESPECTIVE OF WHETHER DIALOGIC OR ITS 
 * OFFICERS, EMPLOYEES, DIRECTORS, SUBSIDIARIES, REPRESENTATIVES, AFFILIATES AND 
 * AGENTS HAVE ADVANCE NOTICE OF THE POSSIBILITY OF SUCH DAMAGES.  THESE 
 * LIMITATIONS SHALL APPLY NOTWITHSTANDING THE FAILURE OF THE ESSENTIAL PURPOSE 
 * OF ANY LIMITED REMEDY.  IN ANY CASE, DIALOGIC'S AND ITS OFFICERS', 
 * EMPLOYEES', DIRECTORS', SUBSIDIARIES', REPRESENTATIVES', AFFILIATES' AND 
 * AGENTS' ENTIRE LIABILITY RELATING TO THE MATERIAL SHALL NOT EXCEED THE 
 * AMOUNTS OF THE FEES THAT YOU PAID FOR THE MATERIAL (IF ANY). THE MATERIALE 
 * IS NOT FAULT-TOLERANT AND IS NOT DESIGNED, INTENDED, OR AUTHORIZED FOR USE IN 
 * ANY MEDICAL, LIFE SAVING OR LIFE SUSTAINING SYSTEMS, OR FOR ANY OTHER 
 * APPLICATION IN WHICH THE FAILURE OF THE MATERIAL COULD CREATE A SITUATION 
 * WHERE PERSONAL INJURY OR DEATH MAY OCCUR. Should You or Your direct or 
 * indirect customers use the MATERIAL for any such unintended or unauthorized 
 * use, You shall indemnify and hold Dialogic and its officers, employees, 
 * directors, subsidiaries, representatives, affiliates and agents harmless 
 * against all claims, costs, damages, and expenses, and attorney fees and 
 * expenses arising out of, directly or indirectly, any claim of product 
 * liability, personal injury or death associated with such unintended or 
 * unauthorized use, even if such claim alleges that Dialogic was negligent 
 * regarding the design or manufacture of the part.
 */
/*testing */
package testing.unit.WebConvergedDemo;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import javax.media.mscontrol.MediaConfigException;
import javax.media.mscontrol.MediaErr;
import javax.media.mscontrol.MediaEvent;
import javax.media.mscontrol.MediaEventListener;
import javax.media.mscontrol.MediaSession;
import javax.media.mscontrol.MsControlException;
import javax.media.mscontrol.Parameters;
import javax.media.mscontrol.join.Joinable;
import javax.media.mscontrol.join.JoinableStream.StreamType;
import javax.media.mscontrol.mixer.MediaMixer;
import javax.media.mscontrol.mixer.MixerEvent;
import javax.media.mscontrol.networkconnection.NetworkConnection;
import javax.media.mscontrol.networkconnection.SdpPortManager;
import javax.media.mscontrol.networkconnection.SdpPortManagerEvent;
import javax.media.mscontrol.networkconnection.SdpPortManagerException;
import javax.media.mscontrol.resource.AllocationEvent;
import javax.media.mscontrol.resource.AllocationEventListener;
import javax.media.mscontrol.resource.video.VideoLayout;
import javax.media.mscontrol.resource.video.VideoRenderer;
import javax.media.mscontrol.resource.video.VideoRendererEvent;
import javax.sdp.MediaDescription;
import javax.sdp.SdpException;
import javax.sdp.SdpFactory;
import javax.sdp.SdpParseException;
import javax.sdp.SessionDescription;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.sip.SipApplicationSession;
import javax.servlet.sip.SipServletContextEvent;
import javax.servlet.sip.SipServletMessage;
import javax.servlet.sip.SipServletRequest;
import javax.servlet.sip.SipServletResponse;
import javax.servlet.sip.SipSession;
import javax.servlet.sip.SipSessionsUtil;
import javax.servlet.sip.SipURI;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.PongMessage;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import testing.DlgcTest;

import com.vendor.dialogic.javax.media.mscontrol.dlgcsmil.DlgcsmilDocument.Dlgcsmil;
import com.vendor.dialogic.javax.media.mscontrol.dlgcsmil.DlgcsmilDocument;
import com.vendor.dialogic.javax.media.mscontrol.dlgcsmil.LayoutDocument.Layout;
import com.vendor.dialogic.javax.media.mscontrol.dlgcsmil.LayoutDocument.Layout.Region;
import com.vendor.dialogic.javax.media.mscontrol.dlgcsmil.ParDocument.Par;
import com.vendor.dialogic.javax.media.mscontrol.dlgcsmil.RefDocument.Ref;
import com.vendor.dialogic.javax.media.mscontrol.dlgcsmil.RegionType.Relativesize;
import com.vendor.dialogic.javax.media.mscontrol.dlgcsmil.TextDocument.Text;



/*testing */

@ServerEndpoint("/dialogic/conf1/{guest-id}") 

public class DlgcConvergedConference extends DlgcTest
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1;
	protected Boolean confServletInitCalled = false;
	Boolean webRTCInitialized=false;
	
	@Override
	public void init(ServletConfig cfg) throws ServletException
	{
		super.init(cfg);
		sessionsUtil = (SipSessionsUtil) getServletContext().getAttribute(SIP_SESSIONS_UTIL);
	}
	
	@Override
	public void servletInitialized(SipServletContextEvent evt){

		String sName = evt.getSipServlet().getServletName();
		
		if( sName.equalsIgnoreCase("DlgcSipServlet") )
		{
			dlgcSipServletLoaded = true;
			log.info(" DlgcConvergedConference::servletInitialized DlgcSipServlet loaded");			
		}

		if( dlgcSipServletLoaded)
		{
			if ( servletInitializedFlag == false ) {
				log.info("Entering DlgcConferenceTest::servletInitialized servletName: " + sName);			
				servletInitializedFlag = true;
				initDriver();
				mySAs = sessionsUtil.getApplicationSessionByKey("DIALOGIC_CONF_DEMO", true);
				Map<String,MediaMixer> mediaMixerMap =  Collections.synchronizedMap(new HashMap<String,MediaMixer>());
				Map<String, CopyOnWriteArraySet<Session>> webSessionConfMap = Collections.synchronizedMap(new HashMap<String,CopyOnWriteArraySet<Session>>());
				Map<String, CopyOnWriteArraySet<Participant>> videoLayoutMap = Collections.synchronizedMap(new HashMap<String,CopyOnWriteArraySet<Participant>>());
				
				mySAs.setAttribute("MEDIA_MIXER_MAP", mediaMixerMap);
				mySAs.setAttribute("WEBSESSION_CONF_MAP", webSessionConfMap);
				mySAs.setAttribute("VIDEO_LAYOUT_MAP", videoLayoutMap);
				
				String mxMode = demoPropertyObj.getProperty("media.mixer.mode");
				String confVideoSize = demoPropertyObj.getProperty("media.mixer.video.size");
				String activeTalker = demoPropertyObj.getProperty("media.mixer.video.vas");
				if (mxMode==null)
					mxMode="AUDIO_VIDEO";
				if (confVideoSize==null)
					confVideoSize="VGA";
				boolean bVAS=false;
				if (activeTalker !=null && activeTalker.equalsIgnoreCase("yes"))
					bVAS = true;
				mySAs.setAttribute("MIXER_MODE", mxMode);
				mySAs.setAttribute("MIXER_VIDEO_SIZE", confVideoSize);
				mySAs.setAttribute("MIXER_VIDEO_VAS", bVAS);
				
				participantLock = new ReentrantLock();
				confLock = new ReentrantLock();

			} else {
				log.info("DlgcConvergedConference::servletInitialized(): already servletInitialized was called...debouncing " + sName);
			}
		}
	}
	
	
	@Override
	public void doInvite(final SipServletRequest request)
	{
		try
		{
			log.debug("^^^^^^^^^^^^^^^^^ DlgcConvergedConference::doInvite()  ^^^^^^^^^^^^^^^^^^^^^");
			
			SipSession session = request.getSession();
			
			NetworkConnection nc = null;
			nc = (NetworkConnection)session.getAttribute("NETWORK_CONNECTION");
			
			if (nc == null)
			{
				MediaSession ms = mscFactory.createMediaSession();
				nc = ms.createNetworkConnection(NetworkConnection.BASIC);
				ms.setAttribute("SIP_SESSION", session);
				ms.setAttribute("NETWORK_CONNECTION", nc);
				ms.setAttribute("REQUEST", request);
				
				
				SipURI sipURI= (SipURI)request.getRequestURI();
				log.info("DlgcConvergedConference request header=::"+sipURI.getUser());
				
				session.setAttribute("MEDIA_SESSION", ms);
				session.setAttribute("NETWORK_CONNECTION", nc);
				
			
				nc.getSdpPortManager().addListener(new DlgcSdpPortEventListener());
			}
			else // reinvite
			{
				
				MediaSession ms = (MediaSession)session.getAttribute("MEDIA_SESSION");
				//NetworkConnection nc = (NetworkConnection)session.getAttribute("NETWORK_CONNECTION");
				if (ms != null)
					ms.setAttribute("REQUEST", request);
				//if (session.getAttribute("REINVITE")!=null)
				{
					if (nc!=null)
					{
						SipServletResponse response = request.createResponse(SipServletResponse.SC_OK);
						try
						{
								response.setContent(nc.getSdpPortManager().getMediaServerSessionDescription(), "application/sdp");
								response.send();
								log.info("DlgcConvergedConference get reinvite sdp -- send same sdp back IIIII");
								return;
						}
						catch (SdpPortManagerException e)
						{
							e.printStackTrace();
						}					
					}
				}
				session.setAttribute("REINVITE", "YES");
			
			}
			
				
							
			
			byte[] remoteSdp = request.getRawContent();
			
			if (remoteSdp == null)
			{
				nc.getSdpPortManager().generateSdpOffer();
			}
			else
			{
				nc.getSdpPortManager().processSdpOffer(remoteSdp);
			}
		}
		catch (MsControlException e)
		{
			e.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
	
	
	
	@Override
	protected void doResponse(SipServletResponse response)
		throws ServletException, IOException
	{
		if (response.getMethod().equals("INVITE"))
		{
			if (response.getStatus() == SipServletResponse.SC_OK)
			{
				try
				{
					NetworkConnection nc = (NetworkConnection) response.getRequest().getSession().getAttribute("NETWORK_CONNECTION");
					byte[] remoteSdp = response.getRawContent();
					if (remoteSdp != null)
					{
						response.getSession().setAttribute("RESPONSE", response);
						nc.getSdpPortManager().processSdpAnswer(remoteSdp);
					}
				}
				catch (MsControlException e)
				{
					e.printStackTrace();
				}
			}
		}
	}
	
	@Override
	public void doBye(final SipServletRequest req)
	throws ServletException, IOException
	{
		MediaSession mediaSession= (MediaSession) req.getSession().getAttribute("MEDIA_SESSION");
		if (mediaSession != null) 
		{
			removeSipSessionCleanup(req);
			mediaSession.release();
		}
			
		req.createResponse(SipServletResponse.SC_OK).send();
		releaseSession(req.getSession());
	}
	
protected boolean isScreenShareEabled(CopyOnWriteArraySet<Participant>pV)
{
	boolean bRet = false;
	for (Participant client : pV) {
		 synchronized (client) {	
			if (client.name.equalsIgnoreCase("screenshare"))
			{
				bRet = true;
				break;
			}
		 }
	}
	return bRet;
}

protected int getVideoPanticipantSize(CopyOnWriteArraySet<Participant>pV)
{
	int size = 0;
	for (Participant client : pV) {
		 synchronized (client) {	
			if (client.bVideo)
				size++;
		 }
	}
	return size;
}
	
protected LayoutSet getVideoLayout(CopyOnWriteArraySet<Participant> pV,Layout.Size.Enum confVideoSize,boolean bActive)
{
		LayoutSet layoutSet= null;
		int pVSize = pV.size();
		
		if (pVSize == 0 )
			return layoutSet;
		
		layoutSet = new LayoutSet();
		
		regionLayout selRegionlayout[]=null;
		DlgcsmilDocument doc = DlgcsmilDocument.Factory.newInstance();
		
		Dlgcsmil dlgcsmil = doc.addNewDlgcsmil();
		Layout  layout = dlgcsmil.addNewHead().addNewLayout();
		layout.setSize(confVideoSize);
		Par par = dlgcsmil.addNewBody().addNewPar();
		Integer i = 1;
		if (bActive)
		{
			if (pVSize <=5)
			{
				selRegionlayout = dlgcsmilSupportRegionTable.get(6);
				
			}
			else
			{
				selRegionlayout = dlgcsmilSupportRegionTable.get(8);
				
			}
			
			Region region =  layout.addNewRegion();
			Ref ref = par.addNewRef();
			Text text=par.addNewText();
			region.setId("1");
			ref.setSrc(VideoLayout.mostActiveStream.toString());
			region.setLeft(selRegionlayout[0].left);
			region.setTop(selRegionlayout[0].top);
			region.setRelativesize(selRegionlayout[0].relativeSize);
			ref.setRegion("1");
			
			text.setRegion("1");
			text.setLeftPosition(60);
			text.setTopPosition(0);
			text.setHorizontalSize(40);
			text.setVerticalSize(10);
			text.setBackgroundOpacity(0);
			text.setTextBackgroundOpacity(0);
			text.setPriority((float) 0.4);
			text.setText("Most Active Talker");
			
			ConfRegion confRegion = new ConfRegion(selRegionlayout[0].top.toString(),
																			  selRegionlayout[0].left.toString(),
																			  selRegionlayout[0].relativeSize.toString(),
																			  VideoLayout.mostActiveStream.toString());
			layoutSet.regionSet.add(confRegion);
			i++;
		}
		else
		{
			if (pVSize == 1)
			{
				selRegionlayout = dlgcsmilSupportRegionTable.get(1);
				
			}
			else if (pVSize == 2)
			{
				selRegionlayout = dlgcsmilSupportRegionTable.get(2);
				
			}
			else if (pVSize <5)
			{
				selRegionlayout = dlgcsmilSupportRegionTable.get(4);
				
			}
			else if (pVSize < 7)
			{
				selRegionlayout = dlgcsmilSupportRegionTable.get(6);
				
			}
			else if (pVSize < 9)
			{
				selRegionlayout = dlgcsmilSupportRegionTable.get(8);
				
			}
			else if (pVSize >=9)
			{
				selRegionlayout = dlgcsmilSupportRegionTable.get(9);
				
			}
		}
		
		if (isScreenShareEabled(pV) && !bActive)
		{
			/*ConfRegion confRegion = new ConfRegion("0", "0","1",	"screenshare");
			layoutSet.regionSet.add(confRegion);
			
			for (Participant client : pV) {
				 synchronized (client) {	
					if (client.name.equalsIgnoreCase("screenshare"))
					{
						Region region =  layout.addNewRegion();
						Ref ref = par.addNewRef();
						region.setId(i.toString());
						region.setLeft(String.valueOf(0));
						region.setTop(String.valueOf(0));
						region.setRelativesize(Relativesize.X_1);
						ref.setRegion(i.toString());
						ref.setSrc(client.nc.getURI().toString());				
					}
					else
					{
						Region region =  layout.addNewRegion();
						Ref ref = par.addNewRef();
						Text text=par.addNewText();
						region.setId(i.toString());
						region.setLeft(String.valueOf(100));
						region.setTop(String.valueOf(100));
						region.setRelativesize(Relativesize.X_1_4);
						ref.setRegion(i.toString());
						
						text.setRegion(i.toString());
						text.setLeftPosition(60);
						text.setTopPosition(0);
						text.setHorizontalSize(40);
						text.setVerticalSize(10);
						text.setBackgroundOpacity(0);
						text.setTextBackgroundOpacity(0);
						
						text.setPriority((float) 0.4);
						
						ref.setSrc(client.nc.getURI().toString());
						text.setText(client.name);		
					}
				 }
				 i++;
				 if (bActive)
				 {
					 if (i>8)
						 break;
				 }
				 else
				 {
					 if (i>9)
						 break;
				 }
		      }*/
			selRegionlayout = dlgcsmilSupportRegionTable.get(8);
			
			// Set Screenshare region
			
			NetworkConnection screenshareNc = null;
			for (Participant client : pV) {
				 synchronized (client) {	
					if (client.name.equalsIgnoreCase("screenshare"))
					{
						screenshareNc = client.nc;
						Region region =  layout.addNewRegion();
						Ref ref = par.addNewRef();
						//Text text=par.addNewText();
						region.setId(i.toString());
						region.setLeft(selRegionlayout[0].left);
						region.setTop(selRegionlayout[0].top);
						region.setRelativesize(selRegionlayout[0].relativeSize);
						ref.setRegion(i.toString());						
						ref.setSrc(client.nc.getURI().toString());
						//text.setText(client.name);				
						ConfRegion confRegion = new ConfRegion(selRegionlayout[0].top.toString(),
																						selRegionlayout[0].left.toString(),
																						selRegionlayout[0].relativeSize.toString(),
																						client.nc.getURI().toString());	
						layoutSet.regionSet.add(confRegion);
						i++;
						break;
						
					}
				 }
			}
			for (Participant client : pV) {
				 synchronized (client) {	
					if (client.nc !=screenshareNc && client.bVideo)
					{
						Region region =  layout.addNewRegion();
						Ref ref = par.addNewRef();
						
						region.setId(i.toString());
						region.setLeft(selRegionlayout[i-1].left);
						region.setTop(selRegionlayout[i-1].top);
						region.setRelativesize(selRegionlayout[i-1].relativeSize);
						ref.setRegion(i.toString());
						ref.setSrc(client.nc.getURI().toString());
						
						Text text=par.addNewText();
						text.setRegion(i.toString());
						text.setLeftPosition(60);
						text.setTopPosition(0);
						text.setHorizontalSize(40);
						text.setVerticalSize(10);
						text.setBackgroundOpacity(0);
						text.setTextBackgroundOpacity(0);
						text.setPriority((float) 0.4);
						text.setText(client.name);			
						
						
						ConfRegion confRegion = new ConfRegion(selRegionlayout[i-1].top.toString(),
																						selRegionlayout[i-1].left.toString(),
																						selRegionlayout[i-1].relativeSize.toString(),
																						client.nc.getURI().toString());
						layoutSet.regionSet.add(confRegion);
						i++;
					}
				 }
				
				 if (i>8)
					 break;
			}
			
			
		}
		else
		{
	        for (Participant client : pV) {
				 synchronized (client) {	
				if (client.bVideo)
				{
					Region region =  layout.addNewRegion();
					Ref ref = par.addNewRef();
					
					region.setId(i.toString());
					region.setLeft(selRegionlayout[i-1].left);
					region.setTop(selRegionlayout[i-1].top);
					region.setRelativesize(selRegionlayout[i-1].relativeSize);
					ref.setRegion(i.toString());
					ref.setSrc(client.nc.getURI().toString());
					
					Text text=par.addNewText();
					text.setRegion(i.toString());
					text.setLeftPosition(60);
					text.setTopPosition(0);
					text.setHorizontalSize(40);
					text.setVerticalSize(10);
					text.setBackgroundOpacity(0);
					text.setTextBackgroundOpacity(0);
					text.setPriority((float) 0.4);			
					text.setText(client.name);	
					
					ConfRegion confRegion = new ConfRegion(selRegionlayout[i-1].top.toString(),
																					selRegionlayout[i-1].left.toString(),
																					selRegionlayout[i-1].relativeSize.toString(),
																					client.nc.getURI().toString());
					layoutSet.regionSet.add(confRegion);
					i++;
				 }
				 
				 if (bActive)
				 {
					 if (i>8)
						 break;
				 }
				 else
				 {
					 if (i>9)
						 break;
				 }
		      }
	        }
		}
	      
		 log.info(doc.toString());

		
		InputStream is;
		try {
			is = new ByteArrayInputStream(doc.toString().getBytes("UTF-8"));
			InputStreamReader in = new InputStreamReader(is, "UTF-8");
			try {
				layoutSet.vl = mscFactory.createVideoLayout(MSML_LAYOUT_MIME, in);
			} catch (MediaConfigException e) {
				e.printStackTrace();
				log.error("Fail to create video layout :"+e.getMessage());
				layoutSet= null;
			}
		} catch (IOException ioex) {
			ioex.printStackTrace();
			log.error("Fail to create video layout :"+ioex.getMessage());
			layoutSet= null;
		}
		
		return layoutSet;

	}
	
	@SuppressWarnings("unchecked")
	protected MediaMixer getMediaMixer(String conf_room)
	{
		confLock.lock();
		MediaMixer mx=null;
		Map<String,MediaMixer> mxMap= (Map<String,MediaMixer>)mySAs.getAttribute("MEDIA_MIXER_MAP");
		Map<String, CopyOnWriteArraySet<Participant>> vMap =  (Map<String,CopyOnWriteArraySet<Participant>>)mySAs.getAttribute("VIDEO_LAYOUT_MAP");
		mx =mxMap.get(conf_room);
		if (mx == null)
		{
			try {
				MediaSession ms = mscFactory.createMediaSession();
				ms.setAttribute("SCREENSHARE", "no");
				Parameters params = ms.createParameters();
				params.put(MediaMixer.MAX_PORTS, 10);
				
				
				ms.setAttribute("connector.asn.louder.sample.time", new Integer(5) );		
				//SVN Add Active Input (ASN) To Mixer
				params.put(MediaMixer.ENABLED_EVENTS, MixerEvent.ACTIVE_INPUTS_CHANGED );	   //enable active talker
				params.put(MediaMixer.MAX_ACTIVE_INPUTS, 4); 

				
				log.info("****************CreateMediaMixer = "+conf_room+"***************************");
				String mxMode = (String)mySAs.getAttribute("MIXER_MODE");
				String confSize = (String)mySAs.getAttribute("MIXER_VIDEO_SIZE");
				if (mxMode == null)
					confSize ="VGA";
				if (confSize == null)
					mxMode ="AUDIO_VIDEO";
				ms.setAttribute("CONFERENCE_VIDEO_SIZE", confSize);
				if (mxMode.equalsIgnoreCase("AUDIO_VIDEO_RENDERING"))
				{
					mx = ms.createMediaMixer(MediaMixer.AUDIO_VIDEO_RENDERING, params);
					
					VideoRenderer confVideoRenderer  = mx.getResource(VideoRenderer.class);
					 if ( confVideoRenderer == null ) {
							log.error("Sorry the mixer has returned a null for the VideoRenderer.. can't apply video layout...");
					 } else {
							log.info ("Found both videoLayout and VideoRender... setting Mixer video renderer layout...");
					
							DlgcConfVideoRendererListener<VideoRendererEvent> VRL= new DlgcConfVideoRendererListener<VideoRendererEvent>()		;
							confVideoRenderer.addListener(VRL);
							mx.getMediaSession().setAttribute("RENDER_LISTENER", VRL);
					 }
				
					CopyOnWriteArraySet<Participant> vP = new CopyOnWriteArraySet<Participant>();
					vMap.put(conf_room, vP);
				}
				else  if (mxMode.equalsIgnoreCase("AUDIO_VIDEO"))
					mx = ms.createMediaMixer(MediaMixer.AUDIO_VIDEO, params);
				else
					mx = ms.createMediaMixer(MediaMixer.AUDIO, params);
				
				mx.addListener(new MixerAllocationEventListener());
				
				MediaEventListener<MixerEvent> activeTalkerListener = new ActiveTalkerListener();
				mx.addListener(activeTalkerListener);
				
				mxMap.put(conf_room, mx);
				
				
			}catch (MsControlException e) {
				log.error(e.getLocalizedMessage());
			}
		}
		confLock.unlock();
		return mx;
	}
	
	private class Participant{
		public NetworkConnection nc;
		public String name;
		public boolean bVideo;
		Participant(){
			bVideo=false;	
		}
	}
	
	private class ConfRegion{
		public String Id;
		public String top;
		public String left;
		public String relativeSize;
		
	private ConfRegion(String sTop, String sLeft, String sSize,String sId)
		{
			Id = sId;
			top = sTop;
			left = sLeft;
			relativeSize = sSize;
		}
	}
	
	private class LayoutSet{
		public VideoLayout vl;
		public Vector<ConfRegion> regionSet;
		
		public LayoutSet(){
			vl = null;
			regionSet = new Vector<ConfRegion>();
		}
	}
	
	
	private class MixerAllocationEventListener implements AllocationEventListener, Serializable {
		/**
		 * 
		 */
		private static final long serialVersionUID = 17564463L;

		@Override
		public void onEvent(AllocationEvent anEvent) {
			// Check if mixer confirmation was successful
			log.info(" MIXER ALLOCATION EVENT: "+anEvent.getEventType());
			
			
			if (anEvent.getEventType().equals(AllocationEvent.ALLOCATION_CONFIRMED)) {
												
					log.info(" RECEIVED ALLOCATION CONFIRMED FOR CONFERENCE: ");
			}
			else if (anEvent.getEventType().equals(AllocationEvent.IRRECOVERABLE_FAILURE)) {
					log.error("Can't enter conference...IRRECOVERABLE_FAILURE ");
			}
			
		}
	}
	
	
	//SVN Add Active Input (ASN) To Mixer
	private class ActiveTalkerListener implements MediaEventListener<MixerEvent>, Serializable {
		
		private static final long serialVersionUID = 1L;

		@Override
		public void onEvent(MixerEvent activeTalkerEvent ) {
			log.info(" MIXER Active Talker EVENT: "+ activeTalkerEvent.getEventType());
			
			Joinable[] activeTalkerList =  activeTalkerEvent.getActiveInputs();
			if ( activeTalkerList != null) {
				NetworkConnection nc = null;
				for( Joinable j : activeTalkerList ) {
					nc = (NetworkConnection) j;
					try {
						String NCID = nc.toString();
						String NCURI = nc.getURI().toString();
						log.debug("DlgcConvergedConference::ActiveTalker NC: " +NCID);
						log.debug("DlgcConvergedConference::ActiveTalker NC URI: " + NCURI); 
					}catch ( Exception e) {
						log.error(e.toString());
					}
					
				}
			}else {
				log.debug("DlgcConvergedConference::ActiveTalkerListener:: receive Active Talker but got a Null Active Talker List");
			}
		}

		
	}
	
	public class DlgcConfVideoRendererListener  <T extends MediaEvent<?>> implements MediaEventListener<T>, Serializable {

		private static final long serialVersionUID = 1;
		
		@Override
		public void onEvent(T theEvent) {
			log.info("Entering DlgcConfVideoRendererListener::onEvent");
			log.info("DlgcConfVideoRendererListener::Type " + theEvent.getEventType() );
			log.info("DlgcConfVideoRendererListener::Source " + theEvent.getSource().toString());
			log.info("DlgcConfVideoRendererListener::ErrorText " + theEvent.getErrorText());				
		}
	}
	
	
	public class DlgcSdpPortEventListener implements MediaEventListener<SdpPortManagerEvent>, Serializable
	{
		/**
		 * 
		 */
		private static final long serialVersionUID = 5742674704860593132L;

		@SuppressWarnings("unchecked")
		@Override
		public void onEvent(SdpPortManagerEvent event)
		{	
			SdpPortManager sdp = event.getSource();
			MediaSession ms = sdp.getMediaSession();
			SipSession session = (SipSession) ms.getAttribute("SIP_SESSION");
			Session webSocketSession = (Session) ms.getAttribute("WEBSOCKET_SESSION");
			NetworkConnection nc = (NetworkConnection) ms.getAttribute("NETWORK_CONNECTION");
			
			log.info("DlgcSdpPortEventListener::Type " + event.getEventType() );
			log.info("DlgcSdpPortEventListener::Source " + event.getSource().toString());
			log.info("DlgcSdpPortEventListener::ErrorText " + event.getErrorText());	
			
			if (event.getEventType().equals(SdpPortManagerEvent.ANSWER_GENERATED))
			{
				if (!event.getError().equals(MediaErr.NO_ERROR))
					return;
			}
			else if (event.getEventType().equals(SdpPortManagerEvent.ANSWER_PROCESSED))
			{
				log.debug("IIIII SdpPortManagerEvent ANSWER_PROCESSED IIIII");
				SipServletResponse response = (SipServletResponse) session.getAttribute("RESPONSE");
				if (response != null)
				{
					try
					{
						response.createAck().send();
					}
					catch (IOException e)
					{
						e.printStackTrace();
					}
				}
				return;
			}
			else if (event.getEventType().equals(SdpPortManagerEvent.UNSOLICITED_OFFER_GENERATED))
			{
				log.debug("IIIII SdpPortManagerEvent UNSOLICITED_OFFER_GENERATED IIIII");
				// Need to send a re-Invite.
				SipServletMessage reInviteMessage = session.createRequest("INVITE");
				try
				{
					byte[] sessionDesc = sdp.getMediaServerSessionDescription();
					reInviteMessage.setContent(sessionDesc, "application/sdp");
					reInviteMessage.send();
				}
				catch (SdpPortManagerException e)
				{
					e.printStackTrace();
				}
				catch (UnsupportedEncodingException e)
				{
					e.printStackTrace();
				}
				catch (IOException e)
				{
					e.printStackTrace();
				}
				return;
				
			}
			
			
			if (webSocketSession!=null)
			{
				byte[] sdpDesc=null;
				try {
					sdpDesc = nc.getSdpPortManager().getMediaServerSessionDescription();
				} catch (SdpPortManagerException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (MsControlException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
				
					JSONObject obj = new JSONObject();
					obj.put("type", "answer");
					String s1 = new String(sdpDesc);
					obj.put("sdp", s1);
					obj.put("id",nc.getURI().toString());
					webSocketSession.getBasicRemote().sendText(obj.toJSONString());
					webSocketSession.getUserProperties().put("NETWORK_CONN", nc);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			else if (session.isValid())
			{
				SipServletRequest request = (SipServletRequest) ms.getAttribute("REQUEST");
				
				if (event.getEventType().equals(SdpPortManagerEvent.ANSWER_GENERATED))
				{
					log.debug("IIIII SdpPortManagerEvent ANSWER_GENERATED IIIII");
					SipServletResponse response = request.createResponse(SipServletResponse.SC_OK);
					try
					{
						
						if (session.getAttribute("REINVITE")!=null)
						{
							response.setContent(sdp.getMediaServerSessionDescription(), "application/sdp");
							response.send();
							log.info("DlgcSdpPortEventListener get reinvite sdp -- do nothing IIIII");
							return;
						}
							
						
						String conf_room="ant";
						
						SipURI sipURI= (SipURI)request.getRequestURI();
						
						String userName = ( (SipURI)request.getFrom().getURI()).getUser();
						
						if (userName==null)
							userName = request.getFrom().getDisplayName();
						if (userName==null)
							userName="unknown";
						
						log.info("DlgcSdpPortEventListener request user "+sipURI.getUser());
						
						String tmp[] = sipURI.getUser().split("=");
						
						if (tmp.length > 1)
							conf_room = tmp[1];
						
						MediaMixer mx = getMediaMixer(conf_room);
						ms.setAttribute("CONF_ROOM", conf_room);
						
						String charset = "UTF-8";
					    
					    //Save the SDP content in a String
					    byte[] rawContent = request.getRawContent();
					    String sdpContent = new String(rawContent, charset);

					    //Use the static method of SdpFactory to parse the content
					    SdpFactory sdpFactory = SdpFactory.getInstance();
					    SessionDescription sessionDescription = sdpFactory.createSessionDescription(sdpContent);
					    
					    Vector mediaVector = sessionDescription.getMediaDescriptions(false);
					    
					    log.info("DlgcConferenceTest request mediaDescription size  "+mediaVector.size());
					    
					    boolean IsVideo=false, IsAudio=false;
					    for (int i=0;i<mediaVector.size();i++)
					    {
					    	MediaDescription md = (MediaDescription) mediaVector.get(i);
					        if (md.getMedia().getMediaType().equalsIgnoreCase("video"))
					        	IsVideo = true;
					        else if (md.getMedia().getMediaType().equalsIgnoreCase("audio"))
					        	IsAudio = true;
					    }
					    
						if (IsVideo && IsAudio)
						{
							Map<String,CopyOnWriteArraySet<Participant>> vMap= (Map<String,CopyOnWriteArraySet<Participant>>)mySAs.getAttribute("VIDEO_LAYOUT_MAP");
							String videoMode = (String)mySAs.getAttribute("MIXER_MODE");
							 if (videoMode ==null)
								 videoMode ="AUDIO_VIDEO";
							 if (videoMode.equalsIgnoreCase("AUDIO_VIDEO_RENDERING"))
							 {
								 Participant p = new Participant();
								 p.name = userName;
								 p.nc = nc;
								 vMap.get(conf_room).add(p);
								 Layout.Size.Enum vSize= Layout.Size.CIF;
								 String videoSize = (String)mySAs.getAttribute("MIXER_VIDEO_SIZE");
								 if (videoSize!=null)
								 {
										 vSize= Layout.Size.Enum.forString(videoSize); 
								 }
								 boolean bVAS=(Boolean)mySAs.getAttribute("MIXER_VIDEO_VAS");
								 LayoutSet vl =null;
								 if (isScreenShareEabled(vMap.get(conf_room)) || bVAS)
								 {
									 if (vMap.get(conf_room).size()<9)
									 {
										 p.bVideo=true;
										 vl = getVideoLayout(vMap.get(conf_room),vSize,bVAS);
									 }
								 }
								 else
								 {
									 if (vMap.get(conf_room).size()<10)
									 {
										 p.bVideo=true;
										 vl = getVideoLayout(vMap.get(conf_room),vSize,bVAS);
									 }
								 }
								// LayoutSet vl = getVideoLayout(vMap.get(conf_room),vSize,bVAS);
								 VideoRenderer confVideoRenderer  = mx.getResource(VideoRenderer.class);
								 if ( confVideoRenderer == null ) {
										log.debug("The mixer does not have Video Renderer.");
								 } else {
										log.debug("Found both videoLayout and VideoRender... setting Mixer video renderer layout...");
										confVideoRenderer.setLayout(vl.vl);
										
										String layoutMsg = createLayoutChangeMsg(vl);
										if (layoutMsg!=null)
											boardcastMsg(conf_room, layoutMsg);
								}
							 }
							 mx.join(Joinable.Direction.DUPLEX, nc);
						}
							
						else if (IsVideo)
							nc.getJoinableStream(StreamType.video).join(Joinable.Direction.DUPLEX, mx);
						else if (IsAudio)
							nc.getJoinableStream(StreamType.audio).join(Joinable.Direction.DUPLEX, mx);
						else
							 log.info("DlgcConferenceTest request sdp does not either audio or video media" );
						
						response.setContent(sdp.getMediaServerSessionDescription(), "application/sdp");
						response.send();
					}
					catch (UnsupportedEncodingException e)
					{
						e.printStackTrace();
					}
					catch (SdpPortManagerException e)
					{
						e.printStackTrace();
					}
					catch (IOException e)
					{
						e.printStackTrace();
					}
					catch (MsControlException e)
					{
						e.printStackTrace();
					} catch (SdpParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SdpException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}	
				}
			}
		}
	}
	
	 public void onWebRTCAnswerAck(Session webSocketSession,String conf_room)
	 {
		 participantLock.lock();
		 //get MediaSession
		 MediaSession mediaSession= (MediaSession)webSocketSession.getUserProperties().get("MEDIASESSION");
		 
		 Participant p = null;
		 if (mediaSession !=null)
		 {
			 NetworkConnection nc = (NetworkConnection) mediaSession.getAttribute("NETWORK_CONNECTION");
			 Map<String,CopyOnWriteArraySet<Participant>> vMap= (Map<String,CopyOnWriteArraySet<Participant>>)mySAs.getAttribute("VIDEO_LAYOUT_MAP");
			 boolean bVAS=(Boolean)mySAs.getAttribute("MIXER_VIDEO_VAS");
			 
			 Layout.Size.Enum vSize= Layout.Size.CIF;
			 String videoSize = (String)mySAs.getAttribute("MIXER_VIDEO_SIZE");
			 if (videoSize!=null)
			 {
					 vSize= Layout.Size.Enum.forString(videoSize); 
			 }
			 
			 try {
				 MediaMixer mx = getMediaMixer(conf_room); 
				
				 LayoutSet layout =null;
				 String videoMode = (String)mySAs.getAttribute("MIXER_MODE");
				 if (videoMode ==null)
					 videoMode ="AUDIO_VIDEO";
				 if (videoMode.equalsIgnoreCase("AUDIO_VIDEO_RENDERING"))
				 {
					 p = new Participant();
					 p.name = (String)webSocketSession.getUserProperties().get("USER_ID");
					 if (p.name.equalsIgnoreCase("screenshare"))
						 mx.getMediaSession().setAttribute("SCREENSHARE","yes");
					 p.nc = nc;
					 vMap.get(conf_room).add(p);
					 
					 
					 
					 int vPSize = getVideoPanticipantSize(vMap.get(conf_room));
					
					 if (isScreenShareEabled(vMap.get(conf_room)) || bVAS)
					 {
						 if (vPSize<8)
						 {
							 p.bVideo=true;
							 layout = getVideoLayout(vMap.get(conf_room),vSize,bVAS);
						 }
					 }
					 else
					 {
						 if (vPSize<9)
						 {
							 p.bVideo=true;
							 layout = getVideoLayout(vMap.get(conf_room),vSize,bVAS);
						 }
					 }
					 VideoRenderer confVideoRenderer  = mx.getResource(VideoRenderer.class);
					 if ( confVideoRenderer == null ) {
							log.debug("The mixer does not have Video Renderer.");
					 } else {
							log.debug("Found both videoLayout and VideoRender... setting Mixer video renderer layout...");
							if (layout!=null)
								confVideoRenderer.setLayout(layout.vl);
					}
				 }
			
				 if (p.bVideo)
					 mx.join(Joinable.Direction.DUPLEX, nc);
				 else{
					 nc.join(Joinable.Direction.RECV, mx);
					 LayoutSet curLayout= getVideoLayout(vMap.get(conf_room),vSize,bVAS);
					 String curLayoutMsg = createLayoutChangeMsg(curLayout);
					 try{
						 webSocketSession.getBasicRemote().sendText(curLayoutMsg);
					 } catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} 
				 }
					 
					// mx.join(Joinable.Direction.RECV, nc);
				 Map<String,CopyOnWriteArraySet<Session>> wcMap= (Map<String,CopyOnWriteArraySet<Session>>)mySAs.getAttribute("WEBSESSION_CONF_MAP");
			     CopyOnWriteArraySet<Session> wsVector  =wcMap.get(conf_room);
			     if (wsVector==null)
			     {
			    	 wsVector = new CopyOnWriteArraySet<Session>();
			    	 wcMap.put(conf_room, wsVector);
			     } 			     
			     wsVector.add(webSocketSession);
			     String msg = createConfChangeMsg(conf_room);
			     if (msg!=null)
			    	 boardcastMsg(conf_room,msg);
			    if (layout!=null)
			    {
					 String layoutMsg = createLayoutChangeMsg(layout);
					 if (layoutMsg!=null)
						 boardcastMsg(conf_room, layoutMsg);
			    }
			     webSocketSession.getUserProperties().put("CONF_ROOM", conf_room);
			} catch (MsControlException e) {
				// TODO Auto-generated catch block
				// e.printStackTrace();
				log.error("Fail to set layout " );
				if (p!=null)
					vMap.get(conf_room).remove(p);
					
			}
		 }
		 participantLock.unlock();
	 }
	 
	 
	 public void onWebRTCOffer(Session webSocketSession ,String SDP)
	 {
		 
		 NetworkConnection networkConnection = null;
		 try 
		{
			MediaSession mediaSession = mscFactory.createMediaSession();
			
			
			Parameters pmap = mediaSession.createParameters();
			
			Integer stimeout = new Integer(5000);
			pmap.put(MediaSession.TIMEOUT, stimeout);
			mediaSession.setParameters(pmap);
			
			networkConnection = mediaSession.createNetworkConnection(NetworkConnection.BASIC);
			
			//not needed for this unit test sample just using it to demonstrate 
			Parameters sdpConfiguration = mediaSession.createParameters();
			Map<String,String>  configurationData = new HashMap<String,String>();
			configurationData.put("SIP_REQ_URI_USERNAME", "msml=777");
			sdpConfiguration.put(SdpPortManager.SIP_HEADERS, configurationData);
			networkConnection.setParameters(sdpConfiguration);
			
			DlgcSdpPortEventListener la = new DlgcSdpPortEventListener();
			networkConnection.getSdpPortManager().addListener(la);
		
			
			log.info("DlgcConferenceTest::onWebRTCOffer.... Setting mediaSession");
			mediaSession.setAttribute("WEBSOCKET_SESSION",webSocketSession);
			mediaSession.setAttribute("NETWORK_CONNECTION", networkConnection);
			
			webSocketSession.getUserProperties().put("MEDIASESSION",mediaSession);
			
			
		}
		catch (MsControlException e)
		{
			try {
				webSocketSession.getBasicRemote().sendText("{\"type\":\"error\",  \"description\" : \"SERVICE UNAVAILABLE\"}");
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		}
			
			
		try
		{
			byte[] remoteSdp = SDP.getBytes();
			
			if (remoteSdp == null)
			{
				networkConnection.getSdpPortManager().generateSdpOffer();
			}
			else
			{
				networkConnection.getSdpPortManager().processSdpOffer(remoteSdp);
			}
		} 
		catch (MsControlException e)
		{
			try {
				webSocketSession.getBasicRemote().sendText("{\"type\":\"ERROR\",  \"description\" : \"SERVICE UNAVAILABLE\"}");
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	 }
	 
	 protected void myWebRTCInitialized()
	 {
		 mySAs=sessionsUtil.getApplicationSessionByKey("DIALOGIC_CONF_DEMO",false);
	 }
	 
	protected String createLayoutChangeMsg(LayoutSet layoutSet)
	{
		 String layout=null;

		if (layoutSet!=null)
		{
			JSONObject obj = new JSONObject();
			 obj.put("type", "layout");
			 JSONArray list = new JSONArray();
			for(int i =0;i<layoutSet.regionSet.size(); i++)
			{
				JSONObject regionObj = new JSONObject();
		    	 regionObj.put("top",layoutSet.regionSet.get(i).top);
		    	 regionObj.put("left",layoutSet.regionSet.get(i).left);
		    	 regionObj.put("size",layoutSet.regionSet.get(i).relativeSize);
		    	 regionObj.put("id", layoutSet.regionSet.get(i).Id);
		    	 list.add(regionObj);
			}
			
			obj.put("regions",list);
			layout =obj.toJSONString();
			log.info("Entering  createLayoutChangeMsg: " + layout);
		}
		
		
		return layout;
	}
	 
	 @SuppressWarnings("unchecked")
	protected String createConfChangeMsg(String conf_room)
	 {
		 Map<String,CopyOnWriteArraySet<Session>> wcMap= (Map<String,CopyOnWriteArraySet<Session>>)mySAs.getAttribute("WEBSESSION_CONF_MAP");
	     CopyOnWriteArraySet<Session> wsVector  =wcMap.get(conf_room);
	     if (wsVector==null)
	    	 return null;
	    
	     JSONObject obj = new JSONObject();
		 obj.put("type", "conf");
		 JSONArray list = new JSONArray();
		
	     for (Session client : wsVector) {
	    	 list.add(client.getUserProperties().get("USER_ID"));
	     }
	     
	     obj.put("parties", list);
	     
	    return obj.toJSONString();
	 }
	 
	 protected void boardcastMsg(String conf_room,String msg)
	 {
		 Map<String,CopyOnWriteArraySet<Session>> wcMap= (Map<String,CopyOnWriteArraySet<Session>>)mySAs.getAttribute("WEBSESSION_CONF_MAP");
	     CopyOnWriteArraySet<Session> wsVector  =wcMap.get(conf_room);
	     if (wsVector==null)
	    	 return;
		 for (Session client : wsVector) {
			 try {
	                  synchronized (client) {      
							client.getBasicRemote().sendText(msg);
	 	              }
			 }
			catch ( IllegalStateException e)
			{
				 log.error("Chat Error: Failed to send message to client: "+e.getMessage());
			}
	         catch (IOException e) {
	                log.error("Chat Error: Failed to send message to client: "+e.getMessage());
	               
	        }
			 catch (Exception e)
			 {
				  log.error("Chat Error: Failed to send message to client: "+e.getMessage());
			 }
		 }

	 }
	 
	 @OnMessage
	    public void onTextMessage(@PathParam("guest-id") String guestID, Session session, String msg) {
	        try {
	        
	                 log.info("DlgcConvergedConference::TextMessage: " + msg+" session Id =" + session.getId()+" Guest-id = "+guestID);
	            		                
	                JSONParser parser=new JSONParser();
          
	           
            		Object obj = parser.parse(msg);
            		
            		JSONObject jsonObject = (JSONObject) obj;
             
            		String type = (String) jsonObject.get("type");
            		if (type.equalsIgnoreCase("offer"))
            		{
            			String userId = (String) jsonObject.get("userid");
            			if (userId == null)
            			{
            				userId = "unknown";
            				 log.warn(" DlgcConvergedConference::TextMessage:  session Id =" + session.getId()+" user-id is missing");
            			}
            			
            			if (userId.equalsIgnoreCase("screenshare"))
            			{
            				MediaMixer ms = getMediaMixer(guestID);
            				if (ms !=null)
            				{
            					
            					String screenStr =(String)ms.getMediaSession().getAttribute("SCREENSHARE");
            					if(screenStr.equalsIgnoreCase("yes"))
            					{
            						session.getBasicRemote().sendText("{\"type\":\"error\", \"description\" : \"Screenshare is being used\"}");
            						return;
            					}
            				}
            			}
            			session.getUserProperties().put("USER_ID",userId);
            			String Sdp = (String) jsonObject.get("sdp");
            			onWebRTCOffer(session,Sdp);
            		}
            		else if (type.equalsIgnoreCase("ok"))
            		{
            			onWebRTCAnswerAck(session,guestID);
            		}
            		else if (type.equalsIgnoreCase("message"))
            		{
            			boardcastMsg(guestID,msg);
            		}
	   
	        } catch (ParseException e) {
	    		e.printStackTrace();
	        } catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        catch ( IllegalStateException e)
			{
	        	e.printStackTrace();
			}
	    }

	    @OnMessage
	    public void onBinaryMessage(Session session, ByteBuffer bb,
	            boolean last) {
	        try {
	            if (session.isOpen()) {
	                session.getBasicRemote().sendBinary(bb, last);
	            }
	        } catch (IOException e) {
	            try {
	                session.close();
	            } catch (IOException e1) {
	                // Ignore
	            }
	        }
	    }

	    /**
	     * Process a received pong. This is a NO-OP.
	     *
	     * @param pm    Ignored.
	     */
	    @OnMessage
	    public void onPongMessage(PongMessage pm) {
	        // NO-OP
	    }
	    
	   
	    
	    @OnOpen
	    public void onOpen(Session session, @PathParam("guest-id") String guestID)
	    {
	    	 log.info("DlgcConvergedConference::OnOpen: session Id =" + session.getId()+" Conf-id = "+guestID);
	    	 try {
	             
	                  session.getBasicRemote().sendText("Connection open on session id" +session.getId());
	                 
	                  if (webRTCInitialized==false)
	                  {
	                	  log.info("DlgcConvergedConference::onOpen: webrtc ini is false  Id =" + session.getId());
		                  initDriver();
						  myWebRTCInitialized();
						  webRTCInitialized=true;
						  session.getUserProperties().put(guestID, session);
	                  }
	          } catch (IOException e) {
	              try {
	                  session.close();
	              } catch (IOException e1) {
	                  // Ignore
	              }
	          }
	    	 
	    	 
	    }
	    
	    @OnClose
	    public void OnClose(Session session) {
	      
	    	log.info(" DlgcConferenceTest::onClose: session Id =" + session.getId());
	    	removeSessionCleanup(session);
	    	
	    }
	    
	    protected void removeParticipant(String conf_room, NetworkConnection nc)
	    {
	    //	 participantLock.lock();
	    	 Map<String,CopyOnWriteArraySet<Participant>> vlMap= (Map<String,CopyOnWriteArraySet<Participant>>)mySAs.getAttribute("VIDEO_LAYOUT_MAP");
	    	 Map<String,MediaMixer>  mxMap =  (Map<String,MediaMixer>)mySAs.getAttribute("MEDIA_MIXER_MAP");
			 MediaMixer mx= mxMap.get(conf_room);
	    	 CopyOnWriteArraySet<Participant> vp = vlMap.get(conf_room);
	    	 boolean bVideo = false;
	    	 if (vp !=null)
	    	 {
		    	for ( Participant p: vp)
		    	{
		    		 synchronized (p) {
		    			 if (p.nc == nc)
		    			 {
		    				 bVideo = p.bVideo;
		    				 if (p.name.equalsIgnoreCase("screenshare"))
		    					 mx.getMediaSession().setAttribute("SCREENSHARE","no");
		    				 vp.remove(p);
		    				 
		    				 break;
		    			 }
		    		 }
		    	}
		    	if (mx!=null)
		    	{
					 VideoRenderer confVideoRenderer=null;
					try {
						confVideoRenderer = mx.getResource(VideoRenderer.class);
					} catch (MsControlException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					 if ( confVideoRenderer == null ) {
							log.debug("Sorry the mixer has returned a null for the VideoRenderer.. can't apply video layout...");
					 } else {
							log.debug("Found both videoLayout and VideoRender... setting Mixer video renderer layout...");
							Layout.Size.Enum vSize= Layout.Size.CIF;
							 String videoSize = (String)mySAs.getAttribute("MIXER_VIDEO_SIZE");
							 if (videoSize!=null)
							 {
									 vSize= Layout.Size.Enum.forString(videoSize); 
							 }
							 boolean bVAS=(Boolean)mySAs.getAttribute("MIXER_VIDEO_VAS");
							 LayoutSet layout = null;//getVideoLayout(vlMap.get(conf_room),vSize,bVAS);
							 Participant p = null;
							 if (bVideo)
							 {
								 p =  AddNextPantipantToVideo(vlMap.get(conf_room));
								 layout =getVideoLayout(vlMap.get(conf_room),vSize,bVAS);
								
								
							 }
							if (layout != null)
							{	
								try {
									confVideoRenderer.setLayout(layout.vl);
									 if (p !=null)
									 {
										 log.info(" DlgcConferenceTest::Get next video partipant");
										 mx.unjoin(p.nc); 
										 mx.join(Joinable.Direction.DUPLEX, p.nc);
									 }
									
									String layoutMsg = createLayoutChangeMsg(layout);
									if (layoutMsg!=null)
										boardcastMsg(conf_room, layoutMsg);
								} catch (MsControlException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
					}
		    	}
	    	 }
	    	// participantLock.unlock();
	    }
	    
	    
	    private Participant  AddNextPantipantToVideo(CopyOnWriteArraySet<Participant> pV) {
	    	Participant participant = null;
	    	for (Participant client : pV) {
	    		 synchronized (client) {	
	    			if (!client.bVideo)
	    			{
	    				log.info(" DlgcConferenceTest::Find next video partipant");
	    				client.bVideo=true;
	    				participant = client;
	    				break;
	    			}
	    		 }
	    	}
	    	return participant;
			
		}

		protected void removeSessionCleanup(Session session)
	    {
	    	participantLock.lock();
	    	MediaSession mediaSession= (MediaSession) session.getUserProperties().get("MEDIASESSION");
	    	if (mediaSession != null)
	    	{
	    		log.info(" DlgcConferenceTest::echoOnClose:  get mediasession obj");
	       	    String conf_room = (String)session.getUserProperties().get("CONF_ROOM");
	    		if (conf_room != null)
	    		{
	    			 Map<String,CopyOnWriteArraySet<Session>> wcMap= (Map<String,CopyOnWriteArraySet<Session>>)mySAs.getAttribute("WEBSESSION_CONF_MAP");
				     CopyOnWriteArraySet<Session> wsVector  =wcMap.get(conf_room);
				    
				     if (wsVector!=null)
				     {
				    	 wsVector.remove(session);
				    	 String msg = createConfChangeMsg(conf_room);
					     if (msg!=null)
					    	 boardcastMsg(conf_room,msg);
				     }
				     NetworkConnection nc = (NetworkConnection)session.getUserProperties().get("NETWORK_CONN");
				     if (nc !=null)
				    	 removeParticipant(conf_room, nc);
	    		}
	    		mediaSession.release();
	    	}
	    	participantLock.unlock();
	    }
	    
	    protected void removeSipSessionCleanup(SipServletRequest req)
	    {
	    	participantLock.lock();
	    	NetworkConnection nc = (NetworkConnection) req.getSession().getAttribute("NETWORK_CONNECTION");
	    	MediaSession mediaSession= (MediaSession) req.getSession().getAttribute("MEDIA_SESSION");
	    	String conf_room=(String) mediaSession.getAttribute("CONF_ROOM");
		
	    	if (nc==null)
	    		return;
	    	
	    	if (mediaSession != null)
	    	{
	    		log.info(" DlgcConferenceTest::echoOnClose:  get mediasession obj");
	    		
	    		
	    		if (conf_room != null)
	       			removeParticipant(conf_room, nc);
	    		mediaSession.release(); 
	      	}
	    	participantLock.unlock();
	    }
	    
	    @OnError
	    public void onError(Session session, Throwable t) {
	          	removeSessionCleanup(session);
	    }
	
		
	
	static Logger log = LoggerFactory.getLogger(DlgcConvergedConference.class);
	private static Lock participantLock;
	private static Lock confLock;
	public static SipSessionsUtil sessionsUtil;
	private transient SipApplicationSession mySAs = null;
	static public final String MSML_LAYOUT_MIME = "application/dlgcsmil+xml";
	
	public static class regionLayout
	{
		public regionLayout(String sTop, String sLeft, Relativesize.Enum size) {
			top = sTop;
			left = sLeft;
			relativeSize=size;
		}
		String top;
		String left;
		Relativesize.Enum relativeSize;
	}
	static public final Map<Integer,regionLayout[]> dlgcsmilSupportRegionTable = new HashMap<Integer,regionLayout[]>();

	static {
		dlgcsmilSupportRegionTable.put(1, new regionLayout[] {new regionLayout(String.valueOf(0),String.valueOf(0),Relativesize.X_1)});
		
		dlgcsmilSupportRegionTable.put(2, new regionLayout[] {new regionLayout(String.valueOf(25),String.valueOf(0),Relativesize.X_1_2),
				new regionLayout(String.valueOf(25),String.valueOf(50),Relativesize.X_1_2),
		});

		dlgcsmilSupportRegionTable.put(4, new regionLayout[] {new regionLayout(String.valueOf(0),String.valueOf(0),Relativesize.X_1_2),
				new regionLayout(String.valueOf(0),String.valueOf(50),Relativesize.X_1_2),
				new regionLayout(String.valueOf(50),String.valueOf(50),Relativesize.X_1_2),
				new regionLayout(String.valueOf(50),String.valueOf(0),Relativesize.X_1_2)
		});

		dlgcsmilSupportRegionTable.put(6, new regionLayout[] {new regionLayout(String.valueOf(0),String.valueOf(0),Relativesize.X_2_3),
				new regionLayout(String.valueOf(0),String.valueOf(66.666),Relativesize.X_1_3),
				new regionLayout(String.valueOf(33.333),String.valueOf(66.666),Relativesize.X_1_3),
				new regionLayout(String.valueOf(66.666),String.valueOf(66.666),Relativesize.X_1_3),
				new regionLayout(String.valueOf(66.666),String.valueOf(33.333),Relativesize.X_1_3),
				new regionLayout(String.valueOf(66.666),String.valueOf(0),Relativesize.X_1_3)
		});

		dlgcsmilSupportRegionTable.put(8, new regionLayout[] {new regionLayout(String.valueOf(0),String.valueOf(0),Relativesize.X_3_4),
				new regionLayout(String.valueOf(0),String.valueOf(75),Relativesize.X_1_4),
				new regionLayout(String.valueOf(25),String.valueOf(75),Relativesize.X_1_4),
				new regionLayout(String.valueOf(50),String.valueOf(75),Relativesize.X_1_4),
				new regionLayout(String.valueOf(75),String.valueOf(75),Relativesize.X_1_4),
				new regionLayout(String.valueOf(75),String.valueOf(50),Relativesize.X_1_4),
				new regionLayout(String.valueOf(75),String.valueOf(25),Relativesize.X_1_4),
				new regionLayout(String.valueOf(75),String.valueOf(0),Relativesize.X_1_4)
		});


		dlgcsmilSupportRegionTable.put(9, new regionLayout[] {new regionLayout(String.valueOf(0),String.valueOf(0),Relativesize.X_1_3),
				new regionLayout(String.valueOf(0),String.valueOf(33.333),Relativesize.X_1_3),
				new regionLayout(String.valueOf(0),String.valueOf(66.666),Relativesize.X_1_3),
				new regionLayout(String.valueOf(33.333),String.valueOf(0),Relativesize.X_1_3),
				new regionLayout(String.valueOf(33.333),String.valueOf(33.333),Relativesize.X_1_3),
				new regionLayout(String.valueOf(33.333),String.valueOf(66.666),Relativesize.X_1_3),
				new regionLayout(String.valueOf(66.666),String.valueOf(0),Relativesize.X_1_3),
				new regionLayout(String.valueOf(66.666),String.valueOf(33.333),Relativesize.X_1_3),
				new regionLayout(String.valueOf(66.666),String.valueOf(66.666),Relativesize.X_1_3)
		});

		dlgcsmilSupportRegionTable.put(10, new regionLayout[] {new regionLayout(String.valueOf(0),String.valueOf(0),Relativesize.X_1_2),
				new regionLayout(String.valueOf(0),String.valueOf(50),Relativesize.X_1_2),
				new regionLayout(String.valueOf(50),String.valueOf(0),Relativesize.X_1_4),
				new regionLayout(String.valueOf(50),String.valueOf(25),Relativesize.X_1_4),
				new regionLayout(String.valueOf(50),String.valueOf(50),Relativesize.X_1_4),
				new regionLayout(String.valueOf(50),String.valueOf(75),Relativesize.X_1_4),
				new regionLayout(String.valueOf(75),String.valueOf(0),Relativesize.X_1_4),
				new regionLayout(String.valueOf(75),String.valueOf(25),Relativesize.X_1_4),
				new regionLayout(String.valueOf(75),String.valueOf(50),Relativesize.X_1_4),
				new regionLayout(String.valueOf(75),String.valueOf(75),Relativesize.X_1_4)
		});

	
	}	
}
