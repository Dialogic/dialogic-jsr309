package testing.unit.WebConvergedDemo;

import java.io.Serializable;

import javax.media.mscontrol.MediaSession;
import javax.media.mscontrol.networkconnection.NetworkConnection;

public class DlgcParticipant  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	DlgcParticipant (String iname, NetworkConnection inc, String itype){
		name = iname;
		nc = inc;
		type = itype;
		bVideo = false;
		ms = nc.getMediaSession();
		
	}
	String name;
	NetworkConnection nc;
	String type;
	boolean bVideo;
	MediaSession ms;
}
