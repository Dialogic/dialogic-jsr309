/*
 * DIALOGIC CONFIDENTIAL
 *
 * Copyright 2010 Dialogic Corporation. All Rights Reserved.
 * The source code contained or described herein and all documents related to
 * the source code (collectively "Material") are owned by Dialogic Corporation 
 * or its suppliers or licensors ("Dialogic"). 
 *
 * BY DOWNLOADING, ACCESSING, INSTALLING, OR USING THE MATERIAL YOU AGREE TO BE
 * BOUND BY THE TERMS AND CONDITIONS DENOTED HERE AND ANY ADDITIONAL TERMS AND
 * CONDITIONS SET FORTH IN THE MATERIAL. Title to the Material remains with 
 * Dialogic. The Material contains trade secrets and proprietary and 
 * confidential information of Dialogic. The Material is protected by worldwide
 * Dialogic copyright(s) and applicable trade secret laws and treaty provisions.
 * No part of the Material may be used, copied, reproduced, modified, published, 
 * uploaded, posted, transmitted, distributed, or disclosed in any way without
 * prior express written permission from Dialogic Corporation.
 *
 * No license under any applicable patent, copyright, trade secret or other 
 *intellectual property right is granted to or conferred upon you by disclosure
 * or delivery of the Material, either expressly, by implication, inducement, 
 * estoppel or otherwise. Any license under any such applicable patent, 
 * copyright, trade secret or other intellectual property rights must be express
 * and approved by Dialogic Corporation in writing.
 *
 * You understand and acknowledge that the Material is provided on an 
 * AS-IS basis, without warranty of any kind.  DIALOGIC DOES NOT WARRANT THAT 
 * THE MATERIAL WILL MEET YOUR REQUIREMENTS OR THAT THE SOURCE CODE WILL RUN 
 * ERROR-FREE OR UNINTERRUPTED.  DIALOGIC MAKES NO WARRANTIES, EXPRESS OR 
 * IMPLIED, INCLUDING, WITHOUT LIMITATION, ANY WARRANTY OF NON-INFRINGEMENT, 
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  DIALOGIC ASSUMES NO 
 * RISK OF ANY AND ALL DAMAGE OR LOSS FROM USE OR INABILITY TO USE THE MATERIAL. 
 * THE ENTIRE RISK OF THE QUALITY AND PERFORMANCE OF THE MATERIAL IS WITH YOU.  
 * IF YOU RECEIVE ANY WARRANTIES REGARDING THE MATERIAL, THOSE WARRANTIES DO NOT 
 * ORIGINATE FROM, AND ARE NOT BINDING ON DIALOGIC.
 *
 * IN NO EVENT SHALL DIALOGIC OR ITS OFFICERS, EMPLOYEES, DIRECTORS, 
 * SUBSIDIARIES, REPRESENTATIVES, AFFILIATES AND AGENTS HAVE ANY LIABILITY TO YOU 
 * OR ANY OTHER THIRD PARTY, FOR ANY LOST PROFITS, LOST DATA, LOSS OF USE OR 
 * COSTS OF PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES, OR FOR ANY INDIRECT, 
 * SPECIAL OR CONSEQUENTIAL DAMAGES RELATING TO THE MATERIAL, UNDER ANY CAUSE OF
 * ACTION OR THEORY OF LIABILITY, AND IRRESPECTIVE OF WHETHER DIALOGIC OR ITS 
 * OFFICERS, EMPLOYEES, DIRECTORS, SUBSIDIARIES, REPRESENTATIVES, AFFILIATES AND 
 * AGENTS HAVE ADVANCE NOTICE OF THE POSSIBILITY OF SUCH DAMAGES.  THESE 
 * LIMITATIONS SHALL APPLY NOTWITHSTANDING THE FAILURE OF THE ESSENTIAL PURPOSE 
 * OF ANY LIMITED REMEDY.  IN ANY CASE, DIALOGIC'S AND ITS OFFICERS', 
 * EMPLOYEES', DIRECTORS', SUBSIDIARIES', REPRESENTATIVES', AFFILIATES' AND 
 * AGENTS' ENTIRE LIABILITY RELATING TO THE MATERIAL SHALL NOT EXCEED THE 
 * AMOUNTS OF THE FEES THAT YOU PAID FOR THE MATERIAL (IF ANY). THE MATERIALE 
 * IS NOT FAULT-TOLERANT AND IS NOT DESIGNED, INTENDED, OR AUTHORIZED FOR USE IN 
 * ANY MEDICAL, LIFE SAVING OR LIFE SUSTAINING SYSTEMS, OR FOR ANY OTHER 
 * APPLICATION IN WHICH THE FAILURE OF THE MATERIAL COULD CREATE A SITUATION 
 * WHERE PERSONAL INJURY OR DEATH MAY OCCUR. Should You or Your direct or 
 * indirect customers use the MATERIAL for any such unintended or unauthorized 
 * use, You shall indemnify and hold Dialogic and its officers, employees, 
 * directors, subsidiaries, representatives, affiliates and agents harmless 
 * against all claims, costs, damages, and expenses, and attorney fees and 
 * expenses arising out of, directly or indirectly, any claim of product 
 * liability, personal injury or death associated with such unintended or 
 * unauthorized use, even if such claim alleges that Dialogic was negligent 
 * regarding the design or manufacture of the part.
 */
/*testing */
package testing.unit.WebConvergedDemo;

import java.io.IOException;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import javax.media.mscontrol.MediaErr;
import javax.media.mscontrol.MediaEventListener;
import javax.media.mscontrol.MediaSession;
import javax.media.mscontrol.MsControlException;
import javax.media.mscontrol.Parameters;
import javax.media.mscontrol.networkconnection.NetworkConnection;
import javax.media.mscontrol.networkconnection.SdpPortManager;
import javax.media.mscontrol.networkconnection.SdpPortManagerEvent;
import javax.media.mscontrol.networkconnection.SdpPortManagerException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.sip.SipApplicationSession;
import javax.servlet.sip.SipServletContextEvent;
import javax.servlet.sip.SipServletMessage;
import javax.servlet.sip.SipServletRequest;
import javax.servlet.sip.SipServletResponse;
import javax.servlet.sip.SipSession;
import javax.servlet.sip.SipSessionsUtil;
import javax.servlet.sip.SipURI;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.PongMessage;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import testing.DlgcTest;




@ServerEndpoint("/dialogic/conf/{guest-id}") 

public class DlgcConvergedConferenceDemo extends DlgcTest
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1;
	protected Boolean confServletInitCalled = false;
	Boolean webRTCInitialized=false;
	
	@Override
	public void init(ServletConfig cfg) throws ServletException
	{
		super.init(cfg);
		sessionsUtil = (SipSessionsUtil) getServletContext().getAttribute(SIP_SESSIONS_UTIL);
	}
	
	@Override
	public void servletInitialized(SipServletContextEvent evt){

		String sName = evt.getSipServlet().getServletName();
		
		if( sName.equalsIgnoreCase("DlgcSipServlet") )
		{
			dlgcSipServletLoaded = true;
			log.info(" DlgcConvergedConference::servletInitialized DlgcSipServlet loaded");			
		}

		if( dlgcSipServletLoaded)
		{
			if ( servletInitializedFlag == false ) {
				log.info("Entering DlgcConvergedConferenceDemo::servletInitialized servletName: " + sName);			
				servletInitializedFlag = true;
				initDriver();
				mySAs = sessionsUtil.getApplicationSessionByKey("DIALOGIC_CONF_DEMO", true);
				Map<String,DlgcConference> confMap =  Collections.synchronizedMap(new HashMap<String,DlgcConference>());
				
				mySAs.setAttribute("CONFERENCE_MAP", confMap);
				
				
				String mxMode = demoPropertyObj.getProperty("media.mixer.mode");
				String confVideoSize = demoPropertyObj.getProperty("media.mixer.video.size");
				String activeTalker = demoPropertyObj.getProperty("media.mixer.video.vas");
				String controlLeg = demoPropertyObj.getProperty("media.mixer.video.controlleg");
				if (mxMode==null)
					mxMode="AUDIO_VIDEO";
				if (confVideoSize==null)
					confVideoSize="VGA";
				boolean bVAS=false;
				boolean bControlLeg =false;
				if (controlLeg !=null && controlLeg.equalsIgnoreCase("yes"))
					bControlLeg = true;
				if (activeTalker !=null && activeTalker.equalsIgnoreCase("yes"))
					bVAS = true;
				mySAs.setAttribute("MIXER_MODE", mxMode);
				mySAs.setAttribute("MIXER_VIDEO_SIZE", confVideoSize);
				mySAs.setAttribute("MIXER_VIDEO_VAS", bVAS);
				mySAs.setAttribute("MIXER_VIDEO_CONTROL_LEG", bControlLeg);
				
				confLock = new ReentrantLock();

			} else {
				log.info("DlgcConvergedConferenceDemo::servletInitialized(): already servletInitialized was called...debouncing " + sName);
			}
		}
	}
	
	
	@Override
	public void doInvite(final SipServletRequest request)
	{
		try
		{
			log.debug("^^^^^^^^^^^^^^^^^ DlgcConvergedConferenceDemo::doInvite()  ^^^^^^^^^^^^^^^^^^^^^");
			
			SipSession session = request.getSession();
			
			NetworkConnection nc = null;
			nc = (NetworkConnection)session.getAttribute("NETWORK_CONNECTION");
			
			if (nc == null)
			{
				MediaSession ms = mscFactory.createMediaSession();
				nc = ms.createNetworkConnection(NetworkConnection.BASIC);
				ms.setAttribute("SIP_SESSION", session);
				ms.setAttribute("NETWORK_CONNECTION", nc);
				ms.setAttribute("REQUEST", request);
				
				
				SipURI sipURI= (SipURI)request.getRequestURI();
				log.info("DlgcConvergedConference request header=::"+sipURI.getUser());
				
				session.setAttribute("MEDIA_SESSION", ms);
				session.setAttribute("NETWORK_CONNECTION", nc);
				
			
				nc.getSdpPortManager().addListener(new DlgcSdpPortEventListener());
			}
			else // reinvite
			{
				
				MediaSession ms = (MediaSession)session.getAttribute("MEDIA_SESSION");
				//NetworkConnection nc = (NetworkConnection)session.getAttribute("NETWORK_CONNECTION");
				if (ms != null)
					ms.setAttribute("REQUEST", request);
				//if (session.getAttribute("REINVITE")!=null)
				{
					if (nc!=null)
					{
						SipServletResponse response = request.createResponse(SipServletResponse.SC_OK);
						try
						{
								response.setContent(nc.getSdpPortManager().getMediaServerSessionDescription(), "application/sdp");
								response.send();
								log.info("DlgcConvergedConference get reinvite sdp -- send same sdp back IIIII");
								return;
						}
						catch (SdpPortManagerException e)
						{
							e.printStackTrace();
						}					
					}
				}
				session.setAttribute("REINVITE", "YES");
			
			}
			
				
							
			
			byte[] remoteSdp = request.getRawContent();
			
			if (remoteSdp == null)
			{
				nc.getSdpPortManager().generateSdpOffer();
			}
			else
			{
				nc.getSdpPortManager().processSdpOffer(remoteSdp);
			}
		}
		catch (MsControlException e)
		{
			e.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
	
	
	
	@Override
	protected void doResponse(SipServletResponse response)
		throws ServletException, IOException
	{
		if (response.getMethod().equals("INVITE"))
		{
			if (response.getStatus() == SipServletResponse.SC_OK)
			{
				try
				{
					NetworkConnection nc = (NetworkConnection) response.getRequest().getSession().getAttribute("NETWORK_CONNECTION");
					byte[] remoteSdp = response.getRawContent();
					if (remoteSdp != null)
					{
						response.getSession().setAttribute("RESPONSE", response);
						nc.getSdpPortManager().processSdpAnswer(remoteSdp);
					}
				}
				catch (MsControlException e)
				{
					e.printStackTrace();
				}
			}
		}
	}
	
	@Override
	public void doBye(final SipServletRequest req)
	throws ServletException, IOException
	{
		MediaSession mediaSession= (MediaSession) req.getSession().getAttribute("MEDIA_SESSION");
		if (mediaSession != null) 
		{
			removeSipSessionCleanup(req);
			mediaSession.release();
		}
			
		req.createResponse(SipServletResponse.SC_OK).send();
		releaseSession(req.getSession());
	}
	
	
	@SuppressWarnings("unchecked")
	protected DlgcConference getConference(String conf_room)
	{
		confLock.lock();
		DlgcConference confMx=null;
		Map<String,DlgcConference> confMap= (Map<String,DlgcConference>)mySAs.getAttribute("CONFERENCE_MAP");
		confMx =confMap.get(conf_room);
		if (confMx == null)
		{
			   confMx= new DlgcConference(conf_room,this.mscFactory);					
				log.info("****************CreateMediaMixer = "+conf_room+"***************************");
				String mxMode = (String)mySAs.getAttribute("MIXER_MODE");
				String confSize = (String)mySAs.getAttribute("MIXER_VIDEO_SIZE");
				Boolean bActiveTalker = (Boolean)mySAs.getAttribute("MIXER_VIDEO_VAS");
				Boolean bControlLeg = (Boolean)mySAs.getAttribute("MIXER_VIDEO_CONTROL_LEG");
				
				if (bActiveTalker == null)
					bActiveTalker = false;
				if (bControlLeg == null)
					bControlLeg = false;
				if (confSize == null)
					confSize ="VGA";
				if (mxMode == null)
					mxMode ="AUDIO_VIDEO";
					
				Parameters params = mscFactory.createParameters();
								
				if (bActiveTalker == false)
				{
					//ms.setAttribute("connector.asn.louder.sample.time", new Integer(5) );		
					//SVN Add Active Input (ASN) To Mixer
					/*params.put(MediaMixer.ENABLED_EVENTS, MixerEvent.ACTIVE_INPUTS_CHANGED );	   //enable active talker event
					params.put(MediaMixer.MAX_ACTIVE_INPUTS, 4);*/
				}

			
			    if (confMx.CreateConference(mxMode, confSize, params,bActiveTalker,bControlLeg))
			    	confMap.put(conf_room, confMx);
			    else
			    	confMx = null;
		}
		confLock.unlock();
		return confMx;
	}
	
		
	
	public class DlgcSdpPortEventListener implements MediaEventListener<SdpPortManagerEvent>, Serializable
	{
		/**
		 * 
		 */
		private static final long serialVersionUID = 5742674704860593132L;

		@SuppressWarnings("unchecked")
		@Override
		public void onEvent(SdpPortManagerEvent event)
		{	
			SdpPortManager sdp = event.getSource();
			MediaSession ms = sdp.getMediaSession();
			SipSession session = (SipSession) ms.getAttribute("SIP_SESSION");
			Session webSocketSession = (Session) ms.getAttribute("WEBSOCKET_SESSION");
			NetworkConnection nc = (NetworkConnection) ms.getAttribute("NETWORK_CONNECTION");
			
			log.info("DlgcSdpPortEventListener::Type " + event.getEventType() );
			log.info("DlgcSdpPortEventListener::Source " + event.getSource().toString());
			log.info("DlgcSdpPortEventListener::ErrorText " + event.getErrorText());	
			
			if (event.getEventType().equals(SdpPortManagerEvent.ANSWER_GENERATED))
			{
				if (!event.getError().equals(MediaErr.NO_ERROR))
					return;
			}
			else if (event.getEventType().equals(SdpPortManagerEvent.ANSWER_PROCESSED))
			{
				log.debug("IIIII SdpPortManagerEvent ANSWER_PROCESSED IIIII");
				SipServletResponse response = (SipServletResponse) session.getAttribute("RESPONSE");
				if (response != null)
				{
					try
					{
						response.createAck().send();
					}
					catch (IOException e)
					{
						e.printStackTrace();
					}
				}
				return;
			}
			else if (event.getEventType().equals(SdpPortManagerEvent.UNSOLICITED_OFFER_GENERATED))
			{
				log.debug("IIIII SdpPortManagerEvent UNSOLICITED_OFFER_GENERATED IIIII");
				// Need to send a re-Invite.
				SipServletMessage reInviteMessage = session.createRequest("INVITE");
				try
				{
					byte[] sessionDesc = sdp.getMediaServerSessionDescription();
					reInviteMessage.setContent(sessionDesc, "application/sdp");
					reInviteMessage.send();
				}
				catch (SdpPortManagerException e)
				{
					e.printStackTrace();
				}
				catch (UnsupportedEncodingException e)
				{
					e.printStackTrace();
				}
				catch (IOException e)
				{
					e.printStackTrace();
				}
				return;
				
			}
			
			
			if (webSocketSession!=null)
			{
				byte[] sdpDesc=null;
				try {
					sdpDesc = nc.getSdpPortManager().getMediaServerSessionDescription();
				} catch (SdpPortManagerException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (MsControlException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
				
					JSONObject obj = new JSONObject();
					obj.put("type", "answer");
					String s1 = new String(sdpDesc);
					obj.put("sdp", s1);
					obj.put("id",nc.getURI().toString());
					webSocketSession.getBasicRemote().sendText(obj.toJSONString());
					webSocketSession.getUserProperties().put("NETWORK_CONN", nc);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			else if (session.isValid())
			{
				SipServletRequest request = (SipServletRequest) ms.getAttribute("REQUEST");
				
				if (event.getEventType().equals(SdpPortManagerEvent.ANSWER_GENERATED))
				{
					log.debug("IIIII SdpPortManagerEvent ANSWER_GENERATED IIIII");
					SipServletResponse response = request.createResponse(SipServletResponse.SC_OK);
					try
					{
						
						if (session.getAttribute("REINVITE")!=null)
						{
							response.setContent(sdp.getMediaServerSessionDescription(), "application/sdp");
							response.send();
							log.info("DlgcSdpPortEventListener get reinvite sdp -- do nothing IIIII");
							return;
						}
							
						
						String conf_room="default";
						
						SipURI sipURI= (SipURI)request.getRequestURI();
						
						String userName = ( (SipURI)request.getFrom().getURI()).getUser();
						
						if (userName==null)
							userName = request.getFrom().getDisplayName();
						if (userName==null)
							userName="unknown";
						
						log.info("DlgcSdpPortEventListener request user "+sipURI.getUser());
						
						String tmp[] = sipURI.getUser().split("=");
						
						if (tmp.length > 1)
							conf_room = tmp[1];
						
						DlgcConference confMx = getConference(conf_room);
						
						if (confMx == null)
						{
							log.error("Fail to get conference with conf room ="+conf_room);
							
							// need to send hangup ?
							ms.release();
							return;
						}
						ms.setAttribute("CONF_ROOM", conf_room);
						
						String charset = "UTF-8";
					    
					    //Save the SDP content in a String
					    byte[] rawContent = request.getRawContent();
					    String sdpContent = new String(rawContent, charset);
					    
					    
					    ms.setAttribute("SESSION_SDP", sdpContent);
					    DlgcParticipant p = new DlgcParticipant(userName,nc,"SIP_SESSION");
					    if (confMx.AddParticipant(p))
					    {
					    	
					    	response.setContent(sdp.getMediaServerSessionDescription(), "application/sdp");
					    	response.send();
					    	ms.setAttribute("PARTICIPANT_OBJ", p);
					    }
					    else
					    {
					    	log.error("Fail to add participant ="+userName+ " to conference room ="+conf_room);
					    	p = null;
					    	ms.release();
					    }
					}
					catch (UnsupportedEncodingException e)
					{
						e.printStackTrace();
					}
					catch (SdpPortManagerException e)
					{
						e.printStackTrace();
					}
					catch (IOException e)
					{
						e.printStackTrace();
					}
				}
			}
		}
	}
	
	 public void onWebRTCAnswerAck(Session webSocketSession,String conf_room)
	 {
		 MediaSession mediaSession= (MediaSession)webSocketSession.getUserProperties().get("MEDIASESSION");
		 
		 String errorMsg=null;
		 DlgcParticipant p = null;
		 if (mediaSession !=null)
		 {
			 NetworkConnection nc = (NetworkConnection) mediaSession.getAttribute("NETWORK_CONNECTION");
			 String userName = (String)webSocketSession.getUserProperties().get("USER_ID");
			 DlgcConference dlgcConf = getConference(conf_room); 
			 if (dlgcConf!=null)
			 {
				 p = new DlgcParticipant(userName,nc,"WEBSOCKET_SESSION");
				if ( dlgcConf.AddParticipant(p))
				{
					mediaSession.setAttribute("PARTICIPANT_OBJ", p);
				}
				else
				{
					errorMsg ="{\"type\":\"error\",  \"description\" : \"FAIL TO JOIN THE CONFERENCE\"}";
					p=null;
					
				}
			 }
			 else
				 errorMsg ="{\"type\":\"error\",  \"description\" : \"CONFERENCE NOT FOUND\"}";			
		 }
		 else
			 errorMsg ="{\"type\":\"error\",  \"description\" : \"INVALID MEDIA SESSION\"}";		
			 
		 if (errorMsg !=null)
		 {
			 try {
					webSocketSession.getBasicRemote().sendText(errorMsg);
					mediaSession.release();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
		 }				
	 }
	 
	 
	 public void onWebRTCOffer(Session webSocketSession ,String SDP)
	 {
		 
		 NetworkConnection networkConnection = null;
		 MediaSession mediaSession=null;
		 try 
		{
			 mediaSession = mscFactory.createMediaSession();
			
			
			Parameters pmap = mediaSession.createParameters();
			
			Integer stimeout = new Integer(5000);
			pmap.put(MediaSession.TIMEOUT, stimeout);
			mediaSession.setParameters(pmap);
			
			networkConnection = mediaSession.createNetworkConnection(NetworkConnection.BASIC);
			
			//not needed for this unit test sample just using it to demonstrate 
			Parameters sdpConfiguration = mediaSession.createParameters();
			Map<String,String>  configurationData = new HashMap<String,String>();
			configurationData.put("SIP_REQ_URI_USERNAME", "msml=777");
			sdpConfiguration.put(SdpPortManager.SIP_HEADERS, configurationData);
			networkConnection.setParameters(sdpConfiguration);
			
			DlgcSdpPortEventListener la = new DlgcSdpPortEventListener();
			networkConnection.getSdpPortManager().addListener(la);
		
			
			log.info("DlgcConferenceTest::onWebRTCOffer.... Setting mediaSession");
			mediaSession.setAttribute("WEBSOCKET_SESSION",webSocketSession);
			mediaSession.setAttribute("NETWORK_CONNECTION", networkConnection);
			mediaSession.setAttribute("SESSION_SDP", SDP);
			
			webSocketSession.getUserProperties().put("MEDIASESSION",mediaSession);
			
			
		}
		catch (MsControlException e)
		{
			try {
				webSocketSession.getBasicRemote().sendText("{\"type\":\"error\",  \"description\" : \"SERVICE UNAVAILABLE\"}");
				
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if (mediaSession!=null)
					mediaSession.release();
			return;
		}
			
			
		try
		{
			byte[] remoteSdp = SDP.getBytes();
			
			if (remoteSdp == null)
			{
				networkConnection.getSdpPortManager().generateSdpOffer();
			}
			else
			{
				networkConnection.getSdpPortManager().processSdpOffer(remoteSdp);
			}
		} 
		catch (MsControlException e)
		{
			try {
				webSocketSession.getBasicRemote().sendText("{\"type\":\"ERROR\",  \"description\" : \"SERVICE UNAVAILABLE\"}");
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if (mediaSession!=null)
				mediaSession.release();
		}
	 }
	 
	 protected void myWebRTCInitialized()
	 {
		 mySAs=sessionsUtil.getApplicationSessionByKey("DIALOGIC_CONF_DEMO",false);
	 }
	 
	
	 
	 @OnMessage
	    public void onTextMessage(@PathParam("guest-id") String guestID, Session session, String msg) {
	        try {
	        
	                 log.info("DlgcConvergedConference::TextMessage: " + msg+" session Id =" + session.getId()+" Guest-id = "+guestID);
	            		                
	                JSONParser parser=new JSONParser();
          
	           
            		Object obj = parser.parse(msg);
            		
            		JSONObject jsonObject = (JSONObject) obj;
             
            		String type = (String) jsonObject.get("type");
            		if (type.equalsIgnoreCase("offer"))
            		{
            			String userId = (String) jsonObject.get("userid");
            			if (userId == null)
            			{
            				userId = "unknown";
            				 log.warn(" DlgcConvergedConference::TextMessage:  session Id =" + session.getId()+" user-id is missing");
            			}
            			            		
            			session.getUserProperties().put("USER_ID",userId);
            			String Sdp = (String) jsonObject.get("sdp");
            			onWebRTCOffer(session,Sdp);
            		}
            		else if (type.equalsIgnoreCase("ok"))
            		{
            			onWebRTCAnswerAck(session,guestID);
            		}	   
            		else if (type.equalsIgnoreCase("message"))
            		{
            			MediaSession mediaSession= (MediaSession) session.getUserProperties().get("MEDIASESSION");
            	    	if (mediaSession != null)
            	    	{
            	    		DlgcParticipant p = (DlgcParticipant)mediaSession.getAttribute("PARTICIPANT_OBJ");
            	    		if (p!=null)
            	    		{
            	    			DlgcConference conf = (DlgcConference)mediaSession.getAttribute("CONFERENCE_OBJ");
            	    			conf.boardcastMsg(msg);
            	    		}
            	    	}
            		}
	        } catch (ParseException e) {
	    		e.printStackTrace();
	        } 
	    }

	    @OnMessage
	    public void onBinaryMessage(Session session, ByteBuffer bb,
	            boolean last) {
	        try {
	            if (session.isOpen()) {
	                session.getBasicRemote().sendBinary(bb, last);
	            }
	        } catch (IOException e) {
	            try {
	                session.close();
	            } catch (IOException e1) {
	                // Ignore
	            }
	        }
	    }

	    /**
	     * Process a received pong. This is a NO-OP.
	     *
	     * @param pm    Ignored.
	     */
	    @OnMessage
	    public void onPongMessage(PongMessage pm) {
	        // NO-OP
	    }
	    
	   
	    
	    @OnOpen
	    public void onOpen(Session session, @PathParam("guest-id") String guestID)
	    {
	    	 log.info("DlgcConvergedConference::OnOpen: session Id =" + session.getId()+" Conf-id = "+guestID);
	    	 try {
	             
	                  session.getBasicRemote().sendText("Connection open on session id" +session.getId());
	                 
	                  if (webRTCInitialized==false)
	                  {
	                	  log.info("DlgcConvergedConference::onOpen: webrtc ini is false  Id =" + session.getId());
		                  initDriver();
						  myWebRTCInitialized();
						  webRTCInitialized=true;
						  session.getUserProperties().put(guestID, session);
	                  }
	          } catch (IOException e) {
	              try {
	                  session.close();
	              } catch (IOException e1) {
	                  // Ignore
	              }
	          }
	    	 
	    	 
	    }
	    
	    @OnClose
	    public void OnClose(Session session) {
	      
	    	log.info(" OnClose: session Id =" + session.getId());
	    	removeSessionCleanup(session);
	    	
	    }
	    
	    
	    
	    
	    protected void removeSessionCleanup(Session session)
	    {
	       	MediaSession mediaSession= (MediaSession) session.getUserProperties().get("MEDIASESSION");
	    	if (mediaSession != null)
	    	{
	    		DlgcParticipant p = (DlgcParticipant)mediaSession.getAttribute("PARTICIPANT_OBJ");
	    		if (p!=null)
	    		{
	    			DlgcConference conf = (DlgcConference)mediaSession.getAttribute("CONFERENCE_OBJ");
	    			conf.RemoveParticipant(p);
	    		}
	    	
	    		//mediaSession.release();
	    	}
	    	
	    }
	    
	    protected void removeSipSessionCleanup(SipServletRequest req)
	    {
	       	MediaSession mediaSession= (MediaSession) req.getSession().getAttribute("MEDIA_SESSION");   	
	    	
	       	if (mediaSession != null)
	    	{
	    		DlgcParticipant p = (DlgcParticipant)mediaSession.getAttribute("PARTICIPANT_OBJ");
	    		if (p!=null)
	    		{
	    			DlgcConference conf = (DlgcConference)mediaSession.getAttribute("CONFERENCE_OBJ");
	    			conf.RemoveParticipant(p);
	    		}
	    	
	    		//mediaSession.release();
	    	}
	    }
	    
	    @OnError
	    public void onError(Session session, Throwable t) {
	          	removeSessionCleanup(session);
	    }
	
		
	
	private static Logger log = LoggerFactory.getLogger(DlgcConvergedConferenceDemo.class);
	private static Lock confLock;
	public static SipSessionsUtil sessionsUtil;
	private transient SipApplicationSession mySAs = null;
	
}
