var a = 0;
switch(a) {
    case 0:
        a++;
        break;
}